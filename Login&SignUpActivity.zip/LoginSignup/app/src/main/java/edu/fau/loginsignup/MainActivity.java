package edu.fau.loginsignup;

import android.annotation.TargetApi;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    EditText usernameInput;
    EditText vistaIDInput;
    EditText passwordInput;
    TextView notificationText;
    MyDBHandler dbHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usernameInput = (EditText) findViewById(R.id.usernameInput);
        vistaIDInput = (EditText) findViewById(R.id.vistaIDInput);
        passwordInput = (EditText) findViewById(R.id.passwordInput);
        notificationText = (TextView) findViewById(R.id.notificationText);
        dbHandler = new MyDBHandler(this, null, null, 1);

        Button button = (Button) findViewById(R.id.signupButton);
        Button button1 = (Button) findViewById(R.id.loginButton);

        button.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        SignupButtonClicked();

                    }
                }
        );
        button1.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        Login();
                    }
                }
        );

    }


    //add new user to database
    public void SignupButtonClicked() {
        if (dbHandler.checkforUser(usernameInput.getText().toString()) == true) {

            Users user = new Users(usernameInput.getText().toString(), passwordInput.getText().toString(), vistaIDInput.getText().toString());
            dbHandler.addUser(user);
            notificationText.setText(usernameInput.getText().toString() + " has been registered");
            vistaIDInput.setText(""); //resets input
        }
        else{
            notificationText.setText(usernameInput.getText().toString() + " is not an available username - Try again");
            vistaIDInput.setText("");
            usernameInput.setText("");
            passwordInput.setText("");
        }
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void Login(){
        String storedPassword = dbHandler.getSingleEntry(usernameInput.getText().toString());
        String enteredPassword = passwordInput.getText().toString();

        if(Objects.equals(enteredPassword, storedPassword)){
            notificationText.setText("Login Successful!");
            //Intent intentSignUP = new Intent(getApplicationContext(), exerciseActivity.class);
            //startActivity(intentSignUP);
        }
        else {
            notificationText.setText("Incorrect login credentials - Try again");

            }
    }


    public void printDatabase() {
        String dbString = dbHandler.databaseToString();
        notificationText.setText(dbString);
        vistaIDInput.setText(""); //resets input
        passwordInput.setText("");
    }
}
