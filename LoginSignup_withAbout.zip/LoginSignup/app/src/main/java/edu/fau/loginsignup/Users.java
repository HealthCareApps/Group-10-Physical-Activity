package edu.fau.loginsignup;

/**
 * Created by myers on 4/27/2016.
 */
public class Users {
    private int _id;
    private String _username;
    private String _password;
    private String _vista;

    public Users() {
    }

    public Users(String username, String password, String vista) {
        this._username = username;
        this._password = password;
        this._vista = vista;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String get_username() {
        return _username;
    }

    public void set_username(String _username) {
        this._username = _username;
    }

    public String get_password() {
        return _password;
    }

    public void set_password(String _password) {
        this._password = _password;
    }

    public String get_vista() {
        return _vista;
    }

    public void set_vista(String _vista) {
        this._vista = _vista;
    }
}
