package edu.fau.loginsignup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import edu.fau.loginsignup.R;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView aboutText = (TextView) findViewById(R.id.AboutText);
        aboutText.setText(Html.fromHtml("<h1>Welcome to Android Physical Therapy</h1><p>This app is designed to make your 'perscribed' exercises easily accessible on your smartphone or tablet. APT will also store recorded information about completed exercise sessions for simple information transfer between you and your healthcare provider. </p>" +
                "<h1>How it works:</h1><p>APT has a separate web interface that your healhcare provider uses to perscribe your exercises. Your healthcare provider has the ability to update your available exercises and recommended duration at any point in your therapy. As you complete your available exercises, a timer will record the duration and keep a log for your healthcare provider to review.</p>" +
                "<B>ADT created by Group 10:</b> <BR> Felipe Soares (FAU Engineering Student) <BR> Leanna Myers (FAU Engineering Student) <BR> Quintin Warren (FAU Engineering Student) <BR> Arielle Labiner (FAU Nursing Student) <BR> Vinicius Sandins (FAU Art Student)"));
        Button button1 = (Button) findViewById(R.id.signoutButton);

        button1.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        Intent out = new Intent(AboutActivity.this, MainActivity.class);
                        startActivity(out);

                    }
                }
        );
    }
}
