package edu.fau.group10.AndroidPhysicalTherapy;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class FragmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(edu.fau.group10.AndroidPhysicalTherapy.R.layout.activity_fragment);

    }


}
