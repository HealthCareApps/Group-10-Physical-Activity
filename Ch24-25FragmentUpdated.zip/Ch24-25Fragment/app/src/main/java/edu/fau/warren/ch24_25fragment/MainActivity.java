package edu.fau.warren.ch24_25fragment;

import android.app.FragmentTransaction;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Layout;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.support.v4.app.Fragment;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import org.w3c.dom.Text;

import java.net.URI;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        FragmentActivityFragment frag = new FragmentActivityFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, frag).commit();
        RelativeLayout myLayout = (RelativeLayout) findViewById(R.id.myrel);
        TextView name = (TextView) findViewById(R.id.textView10);
        name.setText("Insert Name");
        int [] Load = {11, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
        final TextView countdownsec = (TextView) findViewById(R.id.textView11);
        final TextView countdownmin = (TextView) findViewById(R.id.textView16);
        int TextCount = Load[0];
        final TextView [] exercises = new TextView[TextCount];

        int [] getviews = {0,0,0,0,0,0,0,0,0,0,0,0};
        getviews[0] = R.id.textView;
        getviews[1] = R.id.textView2;
        getviews[2] = R.id.textView5;
        getviews[3] = R.id.textView6;
        getviews[4] = R.id.textView7;
        getviews[5] = R.id.textView12;
        getviews[6] = R.id.textView13;
        getviews[7] = R.id.textView14;
        getviews[8] = R.id.textView17;
        getviews[9] = R.id.textView18;
        getviews[10] = R.id.textView19;
        getviews[11] = R.id.textView20;

        for (int z = 0; z < TextCount; ++z)
        {
            exercises[z] = (TextView) findViewById(getviews[z]);
            exercises[z].setText(getexer(Load[z+1]));
        }

        TextView temp;
        for (int a = TextCount; a < 12; ++a)
        {
            temp = (TextView) findViewById(getviews[a]);
            myLayout.removeView(temp);
        }



        final ImageView start = (ImageView) findViewById(R.id.imageView2);
        final ImageView stop = (ImageView) findViewById(R.id.imageView);
        final ImageView reset = (ImageView) findViewById(R.id.imageView3);

        final CountDownTimer count = new CountDownTimer(540000, 1000){
            int sec = 0;
            int min = 0;
            String q;
            String l;
            @Override
            public void onTick(long millisUntilFinished) {
                ++sec;
                if(sec == 60)
                {
                    sec = 0;
                    ++min;
                }
                q = String.valueOf(sec);
                l = String.valueOf(min);
                countdownsec.setText(q);
                countdownmin.setText(l);
            }

            @Override
            public void onFinish() {
                sec = 0;
                min = 0;
                q = String.valueOf(sec);
                l = String.valueOf(min);
                countdownsec.setText(q);
                countdownmin.setText(l);
            }
        };


        start.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {
            count.start();
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                count.cancel();
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                count.onFinish();
            }
        });


        for(int f = 0; f < TextCount; ++f) {
            final int w = f;
            exercises[w].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (exercises[w].getText() == "Ankle Pumps") {
                        FragmentActivityFragment frag = new FragmentActivityFragment();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    } else if (exercises[w].getText() == "Quad Sets") {
                        FragmentActivityFragment2 frag = new FragmentActivityFragment2();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    } else if (exercises[w].getText() == "Gluteal Sets") {
                        FragmentActivityFragment3 frag = new FragmentActivityFragment3();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    } else if (exercises[w].getText() == "Adduction") {
                        FragmentActivityFragment4 frag = new FragmentActivityFragment4();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    }else if (exercises[w].getText() == "Short Arc Quads") {
                        FragmentActivityFragment6 frag = new FragmentActivityFragment6();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    }else if (exercises[w].getText() == "Seated Range of Motion") {
                        FragmentActivityFragment7 frag = new FragmentActivityFragment7();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    }else if (exercises[w].getText() == "Seated Flexion stretch") {
                        FragmentActivityFragment8 frag = new FragmentActivityFragment8();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    }else if (exercises[w].getText() == "Straight Leg Raise") {
                        FragmentActivityFragment9 frag = new FragmentActivityFragment9();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    }else if (exercises[w].getText() == "Knee extension stretch") {
                        FragmentActivityFragment10 frag = new FragmentActivityFragment10();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    }else if (exercises[w].getText() == "Patellar Mobilization") {
                        FragmentActivityFragment11 frag = new FragmentActivityFragment11();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    }
                    else {
                        FragmentActivityFragment5 frag = new FragmentActivityFragment5();
                        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.fragment_container, frag);
                        transaction.commitAllowingStateLoss();
                        count.cancel();
                        count.onFinish();
                    }
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    String getexer(int i)
    {
        if (i == 1)
        {
            return "Ankle Pumps";
        }
        else if (i == 2)
        {
            return "Quad Sets";
        }
        else if (i == 3)
        {
            return "Gluteal Sets";
        }
        else if (i == 4)
        {
            return "Adduction";
        }
        else if (i == 5)
        {
            return "Heel Slides";
        }
        else if (i == 6)
        {
            return "Short Arc Quads";
        }
        else if (i == 7)
        {
            return "Seated Range of Motion";
        }
        else if (i == 8)
        {
            return "Seated Flexion stretch";
        }
        else if (i == 9)
        {
            return "Straight Leg Raise";
        }
        else if (i == 10)
        {
            return "Knee extension stretch";
        }
        else if (i == 11)
        {
            return "Patellar Mobilization";
        }
        return "";
    }
}
